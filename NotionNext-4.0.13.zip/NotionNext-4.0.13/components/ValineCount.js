import { ValineCount } from 'react-valine'

/**
 * 显示评论数
 */
export default ValineCount
